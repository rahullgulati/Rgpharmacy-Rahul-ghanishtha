import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import {DataserviceService} from '../dataservice.service'
import { Md5 } from 'ts-md5';
declare var $: any;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  loginform: FormGroup;
  token:string="";
  userDetails:any;
  name:string;
  


  constructor(private user:UserService ,private fb:FormBuilder,private r:Router, private data: DataserviceService) { 
    if(sessionStorage.getItem('Active User')){
      this.data.token=JSON.parse(sessionStorage.getItem('Active User')|| '{}');

    }
    
  }
  ngDoCheck(){
    this.name=this.data.token;
    

  }

  ngOnInit(): void {
    this.loginform = this.fb.group({
      email: ["",Validators.required],
      password: ["",Validators.required],
    });
  }
  onSubmit(data: any) {
    const md5=new Md5();
    data.password=md5.appendStr(data.password).end();

    console.log(data);
    this.user.getUser(data).subscribe(p => {
      console.log(p);
      this.userDetails = p;
      if (this.userDetails != null) {
        sessionStorage.setItem('Active User', JSON.stringify(this.userDetails.email));
        sessionStorage.setItem('Role', JSON.stringify(this.userDetails.role));
        sessionStorage.setItem('Name', JSON.stringify(this.userDetails.fname));
        this.token = this.userDetails.email;
        this.data.token=this.token;
        console.log(this.data.token);
        $("#exampleModal").modal("hide");

      }
      else {
        this.token = "Not Found";
        this.data.token="";
        //alert("invalid");

      }
      if (sessionStorage.getItem('Active User') != null && this.token != "Not Found") {
        console.log(sessionStorage.getItem('Active User'));                     
 
        if (!sessionStorage.getItem('Active User') == this.userDetails.email) {
          sessionStorage.removeItem('Active User');
          sessionStorage.setItem('Active User', JSON.stringify(this.userDetails.email));
          sessionStorage.setItem('Role', JSON.stringify(this.userDetails.role));
          sessionStorage.setItem('Name', JSON.stringify(this.userDetails.fname));
          console.log(sessionStorage.getItem('Active User'));
          this.token = this.userDetails.email;
          this.data.token=this.token;
        }
        this.r.navigate(['/home']);
        this.r.navigate(['/home']);
      }
    });
  }
  

}
  
  

  
  // login() {
  //   // ... validate
  //   if (this.userDetails != null) {
  //       this.us.loggedInUser = this.userDetails
  //       console.log(this.userDetails)
  //       this.r.navigate(['/home']);
  //   }


