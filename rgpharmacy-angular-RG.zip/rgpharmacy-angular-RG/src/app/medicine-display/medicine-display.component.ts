import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { DataserviceService } from '../dataservice.service';
import { MedicineDisplayService } from '../medicine-display.service';
import { SearchService } from '../search.service';

@Component({
  selector: 'app-medicine-display',
  templateUrl: './medicine-display.component.html',
  styleUrls: ['./medicine-display.component.css']
})
export class MedicineDisplayComponent implements OnInit {
  data:any;
  medicine_display:any;
  counter:number[];
  cart:object={}



  constructor(private md:MedicineDisplayService, private user: DataserviceService,private cartservice:CartService,private s:SearchService) { 
    this.md.getMedicine().subscribe(m=>{ this.medicine_display=m;
      console.log(this.medicine_display);
      this.counter=new Array(this.medicine_display.length);
      for(let c in this.medicine_display){
        this.counter[c]=1;
      }
      console.log(this.counter);
    });
  }

  ngOnInit(): void {
  }
  plusCounter(i:number){
    this.counter[i]++;
  }
  minusCounter(i:number){
    if(this.counter[i]>=2){
      this.counter[i]--;
    }
  }
  addtocart(m:any,i:number){
    console.log(this.user.token)
    this.cart={
      email:this.user.token,
      mid:m.mid,
      total_price: m.price*this.counter[i],
      quantity:this.counter[i]
      
    }
    this.cartservice.postcartdata(this.cart).subscribe(c=>{console.log(this.cart)});

  }
  onSubmit(data:any){
    this.s.search(data.search).subscribe(m=>this.medicine_display=m);

  }


}
