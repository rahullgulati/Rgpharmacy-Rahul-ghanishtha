import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicineDisplayComponent } from './medicine-display.component';

describe('MedicineDisplayComponent', () => {
  let component: MedicineDisplayComponent;
  let fixture: ComponentFixture<MedicineDisplayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MedicineDisplayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicineDisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
