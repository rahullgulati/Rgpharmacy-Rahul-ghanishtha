import { Component, OnInit } from '@angular/core';
import{ NgForm} from '@angular/forms'
import { MedicineService } from '../medicine.service';

@Component({
  selector: 'app-medicine',
  templateUrl: './medicine.component.html',
  styleUrls: ['./medicine.component.css']
})
export class MedicineComponent implements OnInit {

  constructor(private ms:MedicineService) { }
  price:number=0;
  quantity:number=1;

  ngOnInit(): void {
  }
  onSubmit(medicine:any){
    console.log(medicine);
  this.ms.medicine_insert(medicine).subscribe(s=>{console.log(s)});

  }
}
