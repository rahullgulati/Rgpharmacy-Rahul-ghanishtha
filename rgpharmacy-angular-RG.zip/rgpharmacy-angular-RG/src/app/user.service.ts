import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpParameterCodec } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class UserService {
  // private _loggedInUser?:any;
  url:any="http://localhost:60315/api/Users/";
  urllogin:any="http://localhost:60315/api/Login/";

  constructor( private http:HttpClient) { }
  registerUser(users:any){
    return this.http.post(this.url,users);
  }
  getUser(user:any){
    return this.http.post(this.urllogin,user);
    //return this.http.get(this.url,username)

  }
}
//   get loggedInUser() {
//     return this._loggedInUser;
// }
// set loggedInUser(user: any) {
//     this._loggedInUser = user;
// }
