import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-labtest',
  templateUrl: './labtest.component.html',
  styleUrls: ['./labtest.component.css']
})
export class LabtestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
