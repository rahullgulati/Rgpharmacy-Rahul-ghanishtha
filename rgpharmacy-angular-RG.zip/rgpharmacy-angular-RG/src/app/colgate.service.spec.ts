import { TestBed } from '@angular/core/testing';

import { ColgateService } from './colgate.service';

describe('ColgateService', () => {
  let service: ColgateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ColgateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
