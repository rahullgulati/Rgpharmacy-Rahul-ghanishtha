import { TestBed } from '@angular/core/testing';

import { MedicineDisplayService } from './medicine-display.service';

describe('MedicineDisplayService', () => {
  let service: MedicineDisplayService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MedicineDisplayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
