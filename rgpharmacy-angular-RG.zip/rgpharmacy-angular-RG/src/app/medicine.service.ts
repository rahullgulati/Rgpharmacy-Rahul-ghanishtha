import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MedicineService {
  urlmedicine:any="http://localhost:60315/api/Medicines/"

  constructor(private http:HttpClient) { }
  medicine_insert(medicine:any){
    return this.http.post(this.urlmedicine,medicine);
  }
  medicine_update(medicine:any){
    return this.http.put(this.urlmedicine+medicine.mid,medicine)
  }
  medicine_search(mid:any){
    return this.http.get(this.urlmedicine+mid)
  }
}
