import { TestBed } from '@angular/core/testing';

import { DettolService } from './dettol.service';

describe('DettolService', () => {
  let service: DettolService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DettolService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
