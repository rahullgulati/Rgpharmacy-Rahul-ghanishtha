import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ColgateService {

  urlcolgate:string="http://localhost:60315/api/Brand/Colgate";

  constructor(private http:HttpClient) { }
  getColgate(){
    return this.http.get(this.urlcolgate);
  }
}
