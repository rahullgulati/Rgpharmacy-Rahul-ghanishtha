import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ColgateComponent } from './colgate.component';

describe('ColgateComponent', () => {
  let component: ColgateComponent;
  let fixture: ComponentFixture<ColgateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ColgateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ColgateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
