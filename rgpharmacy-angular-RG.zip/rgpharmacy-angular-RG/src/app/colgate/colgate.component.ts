import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { ColgateService } from '../colgate.service';
import { DataserviceService } from '../dataservice.service';

@Component({
  selector: 'app-colgate',
  templateUrl: './colgate.component.html',
  styleUrls: ['./colgate.component.css']
})
export class ColgateComponent implements OnInit {

  data:any;
  health_display:any;
  counter:number[];
  cart:object={}

  constructor(private he:ColgateService,private user:DataserviceService, private cartservice:CartService) {
    this.he.getColgate().subscribe(m=>{ this.health_display=m;
      console.log(this.health_display);
      this.counter=new Array(this.health_display.length);
      for(let c in this.health_display){
        this.counter[c]=1;
      }
      console.log(this.counter);
    });
   }

  ngOnInit(): void {
  }
  plusCounter(i:number){
    this.counter[i]++;
  }
  minusCounter(i:number){
    if(this.counter[i]>=2){
      this.counter[i]--;
    }
  }
  addtocart(m:any,i:number){
    console.log(m);
    this.cart={
      email:this.user.token,
      pid:m.pid,
      total_price: m.price*this.counter[i],
      quantity:this.counter[i]
      
    }
    this.cartservice.postcartdata(this.cart).subscribe(c=>{console.log(this.cart)});

  }

}
