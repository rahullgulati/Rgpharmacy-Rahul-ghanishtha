import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NeviaService {

  urlnevia:string="http://localhost:60315/api/Brand/Nivea";

  constructor(private http:HttpClient) { }
  getNevia(){
    return this.http.get(this.urlnevia);
  }
}
