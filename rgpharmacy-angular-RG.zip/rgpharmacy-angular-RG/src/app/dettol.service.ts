import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DettolService {
  urldettol:string="http://localhost:60315/api/Brand/Dettol";

  constructor(private http:HttpClient) { }
  getDettol(){
    return this.http.get(this.urldettol);
  }

}
