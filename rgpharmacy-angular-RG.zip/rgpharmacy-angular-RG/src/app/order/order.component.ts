import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataserviceService } from '../dataservice.service';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {

  orderForm: FormGroup;
  orderObject: object = {}
  address: string = "";
  totalAmountFinal: number;
  oid: any = 0;
  constructor(private order: OrderService, private fb: FormBuilder, private data: DataserviceService, private rt: Router) {
    // debugger;
    this.totalAmountFinal = data.amount;
    this.orderForm = this.fb.group({
      address: ["", Validators.required],
      payment_method: [""],
      amount: [this.totalAmountFinal]
    });
  }
  ngOnInit(): void {
    if (this.data.amount == 0) {
      alert("you've refreshed the page. Going Back to Cart.")
      this.rt.navigate(['/cart'])
      
    }
  }
  onSubmit(orderData: any) {
    console.log("submit");
    
    // if (this.data.amount == 0) {​​​​​
    //   alert("you've refreshed the page. Going Back to Cart.")
    //   this.rt.navigate(['../cart'])
    // }​​​​​
    if (this.data.amount > 0) {
      let email = sessionStorage.getItem('Active User').replace(/"/g, '')
      this.orderObject = {
        address: orderData.address,
        payment_method: orderData.payment_method,
        amount: orderData.amount,
        email: email
      }
      console.log(this.orderObject);
      this.order.postOrders(this.orderObject).subscribe(o => this.oid = o);
    }
  }

}