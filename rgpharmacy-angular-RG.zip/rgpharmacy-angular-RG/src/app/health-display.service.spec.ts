import { TestBed } from '@angular/core/testing';

import { HealthDisplayService } from './health-display.service';

describe('HealthDisplayService', () => {
  let service: HealthDisplayService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HealthDisplayService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
