import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import {ReactiveFormsModule , FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AfterloginComponent } from './afterlogin/afterlogin.component';
import { MedicineComponent } from './medicine/medicine.component';
import { MedicineDisplayComponent } from './medicine-display/medicine-display.component';
import { HealthComponent } from './health/health.component';
import { HealthDisplayComponent } from './health-display/health-display.component';
import { MedicineUpdateComponent } from './medicine-update/medicine-update.component';
import { CartComponent } from './cart/cart.component';
import { NavbarComponent } from './navbar/navbar.component';
import { AdminComponent } from './admin/admin.component';
import { MedicineAdminDisplayComponent } from './medicine-admin-display/medicine-admin-display.component';
import { HealthcareAdminDisplayComponent } from './healthcare-admin-display/healthcare-admin-display.component';
import { HealthcareUpdateComponent } from './healthcare-update/healthcare-update.component';
import { OrderComponent } from './order/order.component';
import { AsideComponent } from './aside/aside.component';
import { UserComponent } from './user/user.component';
import { CovidComponent } from './covid/covid.component';
import { DettolComponent } from './dettol/dettol.component';
import { NeviaComponent } from './nivea/nevia.component';
import { ColgateComponent } from './colgate/colgate.component';
import { FooterComponent } from './footer/footer.component';
import { LabtestComponent } from './labtest/labtest.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { LastComponent } from './last/last.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    HomeComponent,
    AfterloginComponent,
    MedicineComponent,
    MedicineDisplayComponent,
    HealthComponent,
    HealthDisplayComponent,
    MedicineUpdateComponent,
    CartComponent,
    NavbarComponent,
    AdminComponent,
    MedicineAdminDisplayComponent,
    HealthcareAdminDisplayComponent,
    HealthcareUpdateComponent,
    OrderComponent,
    AsideComponent,
    UserComponent,
    CovidComponent,
    DettolComponent,
    NeviaComponent,
    ColgateComponent,
    FooterComponent,
    LabtestComponent,
    AboutusComponent,
    LastComponent,
  ],
  imports: [
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
