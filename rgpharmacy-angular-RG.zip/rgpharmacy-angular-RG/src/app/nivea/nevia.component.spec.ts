import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NeviaComponent } from './nevia.component';

describe('NeviaComponent', () => {
  let component: NeviaComponent;
  let fixture: ComponentFixture<NeviaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NeviaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NeviaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
