import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HealthcareAdminDisplayComponent } from './healthcare-admin-display.component';

describe('HealthcareAdminDisplayComponent', () => {
  let component: HealthcareAdminDisplayComponent;
  let fixture: ComponentFixture<HealthcareAdminDisplayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HealthcareAdminDisplayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HealthcareAdminDisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
