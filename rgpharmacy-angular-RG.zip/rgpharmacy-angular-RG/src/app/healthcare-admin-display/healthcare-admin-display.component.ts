import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthDisplayService } from '../health-display.service';

@Component({
  selector: 'app-healthcare-admin-display',
  templateUrl: './healthcare-admin-display.component.html',
  styleUrls: ['./healthcare-admin-display.component.css']
})
export class HealthcareAdminDisplayComponent implements OnInit {
  health_display:any;

  constructor(private he:HealthDisplayService,private route:Router) { 
    this. he.getHealth().subscribe(m=>{ this.health_display=m;
      console.log(this.health_display);})
  }

  ngOnInit(): void {
  }
  onUpdate(pid:any){
    this.route.navigate(['/admin/health_update/'+pid]);
  }

}
