import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  urlcart:string="http://localhost:60315/api/Carts/"

  constructor(private http:HttpClient) { }
  postcartdata(cart:any){
    return this.http.post(this.urlcart,cart)
  }
  calldisplay(email:any){
    return this.http.put(this.urlcart,email);
  }
  deletecartdata(id:any){
    return this .http.delete(this.urlcart+id);

  }
}
