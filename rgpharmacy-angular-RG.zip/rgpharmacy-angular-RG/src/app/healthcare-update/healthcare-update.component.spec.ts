import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HealthcareUpdateComponent } from './healthcare-update.component';

describe('HealthcareUpdateComponent', () => {
  let component: HealthcareUpdateComponent;
  let fixture: ComponentFixture<HealthcareUpdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HealthcareUpdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HealthcareUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
