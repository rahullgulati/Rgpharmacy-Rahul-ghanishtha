import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HealthService } from '../health.service';

@Component({
  selector: 'app-healthcare-update',
  templateUrl: './healthcare-update.component.html',
  styleUrls: ['./healthcare-update.component.css']
})
export class HealthcareUpdateComponent implements OnInit {
  id:any;
  health:any;

  constructor(private hc:HealthService,ar:ActivatedRoute) {
    this.id=ar.snapshot.params["pid"]
    hc.health_search(this.id).subscribe(m=>this.health=m);
   }

  ngOnInit(): void {
  }
  onSubmit(healths:any){
    healths.pid=this.id;
    this.hc.health_update(healths).subscribe(m=>{console.log(m);});
    console.log(healths);
  }

}
