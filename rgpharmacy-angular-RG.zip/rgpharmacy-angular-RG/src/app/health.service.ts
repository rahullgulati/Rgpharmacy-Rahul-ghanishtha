import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HealthService {
  urlhealth:any="http://localhost:60315/api/Health_care/"

  constructor(private http:HttpClient) { }
  health_insert(health:any){
    return this.http.post(this.urlhealth,health);
  }
  health_update(health:any){
    return this.http.put(this.urlhealth+health.pid,health)
  }
  health_search(pid:any){
    return this.http.get(this.urlhealth+pid)
  }
}
