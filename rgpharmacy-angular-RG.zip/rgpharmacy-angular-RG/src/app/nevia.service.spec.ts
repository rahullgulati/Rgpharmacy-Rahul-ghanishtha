import { TestBed } from '@angular/core/testing';

import { NeviaService } from './nevia.service';

describe('NeviaService', () => {
  let service: NeviaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NeviaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
