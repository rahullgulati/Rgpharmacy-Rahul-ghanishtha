import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CartService } from '../cart.service';
import { DataserviceService } from '../dataservice.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cartitems: any;
  cartprice: number = 0;
  constructor(private cart: CartService, private ar: ActivatedRoute, private data: DataserviceService) {
    let email = { "email": sessionStorage.getItem('Active User').replace(/"/g, '') }
    this.cart.calldisplay(email).subscribe(c => {
      this.cartitems = c;
      for (let i = 0; i < this.cartitems.length; i++) {
        this.cartprice += this.cartitems[i].total_price;
      }
      this.data.amount=this.cartprice;
    }
     
    )

  }

  ngOnInit(): void {
    let email = { "email": sessionStorage.getItem('Active User').replace(/"/g, '') }
    this.cart.calldisplay(email).subscribe(e => {
      console.log(e);
      this.cartitems = e;
    });
  }
  onDelete(id: any, index: number) {
    this.cart.deletecartdata(id).subscribe(c => {
      console.log(c);
      delete this.cartitems[index];

    });
    // console.log(id,index)

  }


}
