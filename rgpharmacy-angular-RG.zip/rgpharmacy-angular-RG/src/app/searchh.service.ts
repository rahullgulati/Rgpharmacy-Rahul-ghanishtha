import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SearchhService {

  constructor(private http:HttpClient) { }
  search(ser:string){
    return this.http.get('http://localhost:60315/api/Health_care_search/get?name='+ser);

  }
}
