import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MedicineService } from '../medicine.service';

@Component({
  selector: 'app-medicine-update',
  templateUrl: './medicine-update.component.html',
  styleUrls: ['./medicine-update.component.css']
})
export class MedicineUpdateComponent implements OnInit {
  id:string;
  medicine:any;

  constructor(private md:MedicineService,ar:ActivatedRoute) { 
    this.id=ar.snapshot.params["mid"]
    //console.log(this.id);
    md.medicine_search(this.id).subscribe(m=>this.medicine=m);
  }

  ngOnInit(): void {
  }
  onSubmit(medicines:any){
    medicines.mid=this.id;
    this.md.medicine_update(medicines).subscribe(m=>{console.log(m);});
    console.log(medicines);
  }

}
