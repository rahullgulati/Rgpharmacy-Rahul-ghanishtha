import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';

@Component({
  selector: 'app-health',
  templateUrl: './health.component.html',
  styleUrls: ['./health.component.css']
})
export class HealthComponent implements OnInit {

  constructor(private health:HealthService) { }
  price:number=0;
  quantity:number=1;

  ngOnInit(): void {
  }
  onSubmit(health:any){
    console.log(health);
  this.health.health_insert(health).subscribe(s=>{console.log(s)});

}
}

