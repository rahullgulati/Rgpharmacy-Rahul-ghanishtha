import { Component, Input, OnInit } from '@angular/core';
import { SearchService } from '../search.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  name:string='not'; 

  constructor(private s:SearchService) { 
    console.log(this.name);
  }

  ngOnInit(): void {
    if(sessionStorage.getItem('Name'))
    this.name=sessionStorage.getItem('Name').replace(/"/g,'');
    else
    this.name='not';
  }

  ngDoCheck(){
    if(sessionStorage.getItem('Name'))
    this.name=sessionStorage.getItem('Name').replace(/"/g,'');
    else
    this.name='not';
    
  }
  logout(){
    this.name='not';
    sessionStorage.removeItem('Active User')
    sessionStorage.removeItem('Role')
    sessionStorage.removeItem('Name')
  }
  onSubmit(data:any){
    this.s.search(data.search).subscribe(m=>console.log(m));

  }

}
