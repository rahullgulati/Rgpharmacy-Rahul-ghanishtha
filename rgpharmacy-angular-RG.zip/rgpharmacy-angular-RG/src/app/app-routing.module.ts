import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AdminComponent } from './admin/admin.component';
import { AfterloginComponent } from './afterlogin/afterlogin.component';
import { AsideComponent } from './aside/aside.component';
import { AuthGuard } from './auth.guard';
import { CartComponent } from './cart/cart.component';
import { ColgateComponent } from './colgate/colgate.component';
import { CovidComponent } from './covid/covid.component';
import { DettolComponent } from './dettol/dettol.component';
import { HealthDisplayComponent } from './health-display/health-display.component';
import { HealthComponent } from './health/health.component';
import { HealthcareAdminDisplayComponent } from './healthcare-admin-display/healthcare-admin-display.component';
import { HealthcareUpdateComponent } from './healthcare-update/healthcare-update.component';
import { HomeComponent } from './home/home.component';
import { LabtestComponent } from './labtest/labtest.component';
import { LastComponent } from './last/last.component';
import { LoginGuard } from './login.guard';
import { LoginComponent } from './login/login.component';
import { MedicineAdminDisplayComponent } from './medicine-admin-display/medicine-admin-display.component';
import { MedicineDisplayComponent } from './medicine-display/medicine-display.component';
import { MedicineUpdateComponent } from './medicine-update/medicine-update.component';
import { MedicineComponent } from './medicine/medicine.component';
import { NeviaComponent } from './nivea/nevia.component';
import { OrderComponent } from './order/order.component';
import { RegisterComponent } from './register/register.component';
import { UserComponent } from './user/user.component';

const routes: Routes = [
  {path:'',redirectTo:'home',pathMatch:'full'},
  {path:'register',component:RegisterComponent},
  {path:'home',component:HomeComponent},
  {path:'afterlogin',component:AfterloginComponent},
  {path:'cart',component:CartComponent,canActivate:[LoginGuard]},
  {path:'order',component:OrderComponent},
  {path:'last',component:LastComponent},
  {path:'login',component:LoginComponent},
  {path:'book',component:LabtestComponent},
  {path:'aboutus',component:AboutusComponent},
  {path:'user',component:UserComponent,
  children:[
    {path:'display',component:MedicineDisplayComponent},
    {path:'health_display',component:HealthDisplayComponent},
    {path:'covid',component:CovidComponent},
    {path:'nevia',component:NeviaComponent},
    {path:'colgate',component:ColgateComponent},
    {path:'dettol',component:DettolComponent},
  ]},
  
  {path:'admin',component:AdminComponent,canActivate:[AuthGuard],
  children:[
    {path:'',redirectTo:'medicine_admin',pathMatch:'full'},
    {path:'medicine_admin',component:MedicineAdminDisplayComponent},
    {path:'health_admin', component:HealthcareAdminDisplayComponent},
    {path:'health_insert',component:HealthComponent},
    {path:'medicine_insert',component:MedicineComponent},
    {path:'medicine_update/:mid',component:MedicineUpdateComponent},
    {path:'health_update/:pid',component:HealthcareUpdateComponent}
  ]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
