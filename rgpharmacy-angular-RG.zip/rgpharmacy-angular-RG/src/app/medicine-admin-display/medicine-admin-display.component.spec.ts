import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicineAdminDisplayComponent } from './medicine-admin-display.component';

describe('MedicineAdminDisplayComponent', () => {
  let component: MedicineAdminDisplayComponent;
  let fixture: ComponentFixture<MedicineAdminDisplayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MedicineAdminDisplayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicineAdminDisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
