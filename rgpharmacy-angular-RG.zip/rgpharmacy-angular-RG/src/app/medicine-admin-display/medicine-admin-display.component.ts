import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MedicineDisplayService } from '../medicine-display.service';

@Component({
  selector: 'app-medicine-admin-display',
  templateUrl: './medicine-admin-display.component.html',
  styleUrls: ['./medicine-admin-display.component.css']
})
export class MedicineAdminDisplayComponent implements OnInit {
  medicine_display:any;

  constructor(private me:MedicineDisplayService,private route:Router) { 
    this.me.getMedicine().subscribe(m=>{ this.medicine_display=m;
      console.log(this.medicine_display);})
  }

  ngOnInit(): void {
  }
  onUpdate(mid:any){
    this.route.navigate(['/admin/medicine_update/'+mid]);
  }

}
