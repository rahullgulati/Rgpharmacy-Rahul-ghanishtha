import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HealthDisplayService {
  urlhealth:any="http://localhost:60315/api/Health_care/"

  constructor(private http:HttpClient) { }
  getHealth(){
    return this.http.get(this.urlhealth);
  }

}
