import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MedicineDisplayService {
  urlmedicine:any="http://localhost:60315/api/Medicines/";

  constructor(private http:HttpClient) {

   }
  getMedicine(){
    return this.http.get(this.urlmedicine);
  }
}
