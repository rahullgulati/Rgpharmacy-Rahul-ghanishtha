import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { UserService } from '../user.service';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms'
import { Router } from '@angular/router';
import { Md5 } from 'ts-md5';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls:['./register.component.css'],
  encapsulation:ViewEncapsulation.None
})
export class RegisterComponent implements OnInit {
  registerform: FormGroup;
  msg:boolean=false;

  constructor(private us:UserService,private fb:FormBuilder,private r:Router) {
    
   }

  ngOnInit(): void {
    this.registerform=new FormGroup({
      fname:new FormControl('',Validators.compose([
          Validators.required,
          Validators.pattern('[a-z A-Z]+')
      ])),
      lname:new FormControl('',Validators.compose([
        Validators.required,
        Validators.pattern('[a-z A-Z]+')
    ])),
      email:new FormControl('',Validators.compose([
        Validators.required,
        Validators.pattern("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$")
      ])),
      phone_no:new FormControl('',Validators.compose([
        Validators.required,
        Validators.pattern('^\\d{10}$')
    ])),
    dob:new FormControl('',Validators.compose([
      Validators.required
      
  ])),
      address:new FormControl('',Validators.compose([
        Validators.required
    ])),
    password:new FormControl('',Validators.compose([
      Validators.required,
      //Validators.pattern('^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$')
  ])),
    


      
  })
  }
  onSubmit(user:any){
    console.log(user);
    const md5=new Md5(); 
    user.password=md5.appendStr(user.password).end();
    console.log(user);
    this.us.registerUser(user).subscribe(s=>console.log(user))
    this.msg=true;
  }
  closeAlert(){
    this.msg=false;
    this.r.navigate(['./home']);
  }

}
